import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger
} from "./chunk-ZA4BJULE.js";
import "./chunk-OKGMQ4YE.js";
import "./chunk-5DDH4LSY.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-23KBYUND.js";
import "./chunk-O427KUKJ.js";
import "./chunk-WVYPJOXS.js";
import "./chunk-YIADHJGY.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-WRGSDC5N.js";
import "./chunk-2T7IYMCF.js";
import "./chunk-N7OWGJTN.js";
import "./chunk-YW37EZT7.js";
import "./chunk-47OJ3KCZ.js";
import "./chunk-4ZJKWKT6.js";
import "./chunk-MCOA2TNI.js";
import "./chunk-46HAYV32.js";
import "./chunk-KBORYM44.js";
import "./chunk-DWF6XPVQ.js";
import "./chunk-5EG33CFQ.js";
import "./chunk-2XKXWSIF.js";
import "./chunk-3BESQBIC.js";
import "./chunk-NAVIRHLY.js";
import "./chunk-BXCFCDHR.js";
import "./chunk-EV5IC2DF.js";
import "./chunk-SWEFBSHK.js";
import "./chunk-CRFEH54C.js";
import "./chunk-WQYGOFO6.js";
import "./chunk-IMDIBY5Y.js";

// node_modules/@angular/material/fesm2022/select.mjs
var matSelectAnimations = {
  // Represents
  // trigger('transformPanel', [
  //   state(
  //     'void',
  //     style({
  //       opacity: 0,
  //       transform: 'scale(1, 0.8)',
  //     }),
  //   ),
  //   transition(
  //     'void => showing',
  //     animate(
  //       '120ms cubic-bezier(0, 0, 0.2, 1)',
  //       style({
  //         opacity: 1,
  //         transform: 'scale(1, 1)',
  //       }),
  //     ),
  //   ),
  //   transition('* => void', animate('100ms linear', style({opacity: 0}))),
  // ])
  /** This animation transforms the select's overlay panel on and off the page. */
  transformPanel: {
    type: 7,
    name: "transformPanel",
    definitions: [
      {
        type: 0,
        name: "void",
        styles: {
          type: 6,
          styles: { opacity: 0, transform: "scale(1, 0.8)" },
          offset: null
        }
      },
      {
        type: 1,
        expr: "void => showing",
        animation: {
          type: 4,
          styles: {
            type: 6,
            styles: { opacity: 1, transform: "scale(1, 1)" },
            offset: null
          },
          timings: "120ms cubic-bezier(0, 0, 0.2, 1)"
        },
        options: null
      },
      {
        type: 1,
        expr: "* => void",
        animation: {
          type: 4,
          styles: { type: 6, styles: { opacity: 0 }, offset: null },
          timings: "100ms linear"
        },
        options: null
      }
    ],
    options: {}
  }
};
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
