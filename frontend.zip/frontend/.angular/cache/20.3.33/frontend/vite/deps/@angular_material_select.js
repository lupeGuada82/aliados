import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger
} from "./chunk-QFN6MEQR.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-ABO4TAPQ.js";
import "./chunk-ORSLNZVM.js";
import "./chunk-3RBHQHVZ.js";
import "./chunk-OGLHPSQ5.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-MKYYLXJ7.js";
import "./chunk-5DDH4LSY.js";
import "./chunk-2T7IYMCF.js";
import "./chunk-3BESQBIC.js";
import "./chunk-KLGVXCR7.js";
import "./chunk-NAVIRHLY.js";
import "./chunk-47OJ3KCZ.js";
import "./chunk-4K2DI5N6.js";
import "./chunk-YW37EZT7.js";
import "./chunk-4ZJKWKT6.js";
import "./chunk-46HAYV32.js";
import "./chunk-UEPQ4FL7.js";
import "./chunk-ANULAQSH.js";
import "./chunk-5EG33CFQ.js";
import "./chunk-2XKXWSIF.js";
import "./chunk-BXCFCDHR.js";
import "./chunk-EV5IC2DF.js";
import "./chunk-SWEFBSHK.js";
import "./chunk-CRFEH54C.js";
import "./chunk-WQYGOFO6.js";
import "./chunk-IMDIBY5Y.js";

// node_modules/@angular/material/fesm2022/select.mjs
var matSelectAnimations = {
  // Represents
  // trigger('transformPanel', [
  //   state(
  //     'void',
  //     style({
  //       opacity: 0,
  //       transform: 'scale(1, 0.8)',
  //     }),
  //   ),
  //   transition(
  //     'void => showing',
  //     animate(
  //       '120ms cubic-bezier(0, 0, 0.2, 1)',
  //       style({
  //         opacity: 1,
  //         transform: 'scale(1, 1)',
  //       }),
  //     ),
  //   ),
  //   transition('* => void', animate('100ms linear', style({opacity: 0}))),
  // ])
  /** This animation transforms the select's overlay panel on and off the page. */
  transformPanel: {
    type: 7,
    name: "transformPanel",
    definitions: [
      {
        type: 0,
        name: "void",
        styles: {
          type: 6,
          styles: { opacity: 0, transform: "scale(1, 0.8)" },
          offset: null
        }
      },
      {
        type: 1,
        expr: "void => showing",
        animation: {
          type: 4,
          styles: {
            type: 6,
            styles: { opacity: 1, transform: "scale(1, 1)" },
            offset: null
          },
          timings: "120ms cubic-bezier(0, 0, 0.2, 1)"
        },
        options: null
      },
      {
        type: 1,
        expr: "* => void",
        animation: {
          type: 4,
          styles: { type: 6, styles: { opacity: 0 }, offset: null },
          timings: "100ms linear"
        },
        options: null
      }
    ],
    options: {}
  }
};
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
