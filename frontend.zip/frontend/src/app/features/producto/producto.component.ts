import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AbstractEntityComponent } from '../abstract-entity/abstract-entity.component';
import { BaseService } from '../../core/services/base.service';
import { ColumnSetting, CustomAction, EditorColumnSetting, TableConfiguration } from '../../shared/components/table/utils/utils';
import { TableComponent } from '../../shared/components/table/table.component';
import { CommonModule } from '@angular/common';
import { ButtonComponent } from '../../shared/components/button/button.component';
import { LoadingOverlayComponent } from '../../shared/components/loading-overlay/loading-overlay.component';
import { DocumentoService } from '../../core/services/document-service';
import { MatTableDataSource } from '@angular/material/table';
import { StockEditorComponent } from '../components/stock-editor.component/stock-editor.component';


@Component({
  selector: 'app-producto',
  standalone: true,
  imports: [
    CommonModule, ButtonComponent, TableComponent
  ],
  templateUrl: './producto.component.html',
  styleUrl: './producto.component.scss'
})
export class ProductoComponent implements OnInit {
  displayedColumns: any[] = [];
  data: MatTableDataSource<any> | undefined;
  settings = new TableConfiguration();

  selectedFile: File | null = null;
  processing = false;

  constructor(
    route: ActivatedRoute, private documentoService: DocumentoService,
    router: Router,
    private titleService: Title) {
  }

  createTable() {
    this.displayedColumns = [
      new ColumnSetting({
        key: 'cantidad',
        label: 'Cantidad',
        cellClass: (row) => 'column-cantidad'
      }),

      new ColumnSetting({
        key: 'unidad',
        label: 'Unidad',
        cellClass: (row) => 'column-unidad'
      }),
      new ColumnSetting({
        key: 'descripcion',
        label: 'Descripción',
        cellClass: (row) => 'column-descripcion'

      }),

      new ColumnSetting({
        key: 'productoMatch',
        visible: true,
        label: 'Stock',
        isEditable: true,
        cellClass: (row) => 'column-productoMatch',
        sortBy: (item) => item?.productoMatch ? `${item.productoMatch.nombre} ` : '',
        valueGetter: (row) => {
          const prod = row?.productoMatch;
          if (!prod) return '';
          return `${prod.nombre ?? ''}`;
        },
        editor: new EditorColumnSetting({
          type: 'custom', component: StockEditorComponent
        })
      })

    ];
    this.settings.columns = this.displayedColumns;
    this.settings.columns = this.displayedColumns;
    this.settings.editable = true;
    this.settings.createEditAction = true;
    this.settings.createHidenAction = false;
    this.settings.createExportAction = false;
    this.settings.pagination.pageSize = 10;
    var imputarStock = new CustomAction({
      icon: 'inventory',
      label: 'Imputar Stock',
      action: (row) => this.imputarStock(row),
      condicion: (row: any) => row.productoMatch != null && row.productoMatch != undefined,
    })
    this.settings.customActions = [imputarStock];

  }

  imputarStock(row: any) {
    console.log('Imputar stock for row:', row);
  }
  ngOnInit(): void {
    this.titleService.setTitle(this.getTitle());
  }

  protected getTitle(): string {
    return 'Cargar Stock';
  }

  atras() {
    window.history.back()
  }




  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) {
      return;
    }
    this.selectedFile = input.files[0];
  }

  procesarArchivo(): void {
    if (!this.selectedFile) {
      return;
    }
    this.processing = true;
    this.documentoService.procesarArchivo(this.selectedFile)
      .subscribe({
        next: datos => {
          this.data = new MatTableDataSource(datos);
          console.log(datos)
          this.createTable();
          this.processing = false;
        },
        error: error => {
          console.error('Error:', error);
          this.processing = false;
        }
      });
  }
}
