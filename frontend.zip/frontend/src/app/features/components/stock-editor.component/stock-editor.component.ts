import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { DefaultEditor } from '../../../shared/components/table/utils/defaultEditor';
import { SelectCustomEditorComponent } from '../../../shared/components/select-custom-table/select-custom-table.component';
import { BaseService } from '../../../core/services/base.service';

@Component({
  selector: 'stock-editor',
  imports: [CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    SelectCustomEditorComponent],
  templateUrl: './stock-editor.component.html',
  styleUrl: './stock-editor.component.scss'
})
export class StockEditorComponent extends DefaultEditor implements OnInit {
  // search: any;
  productos: any[] = [];
  private service = inject(BaseService<any>);

  constructor() {
    super();
  }


  ngOnInit() {
    this.service.getByDescripcion(this.row().descripcion, this.getPath()).subscribe((datos: any[]) => {
      this.productos = datos;
    });

  }
  protected getPath(): string {
    return 'producto/';

  }
  configurarControls(): void {
    const control = this.control();
    if (!control) {
      return;
    }
    const entity = this.row()?.[this.column().key];
    if (entity) {
      const found = this.productos?.find(u => this.valueProducto(u) === entity?.nombre);
      if (found) control.setValue(found, { emitEvent: false });
    }


  }


  displayProducto = (u: any) =>
    `${u.codigo} ${u.nombre}`;

  displaySelectProducto = (u: any) =>
    u.nombre;

  valueProducto = (u: any) =>
    u.nombre;
}