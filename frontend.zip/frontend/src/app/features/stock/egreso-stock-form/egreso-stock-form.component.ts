import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DetalleStockService } from '../../../core/services/detalleStock.service';
import { BaseService } from '../../../core/services/base.service';
import { ButtonComponent } from '../../../shared/components/button/button.component';
import { LoadingOverlayComponent } from '../../../shared/components/loading-overlay/loading-overlay.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

@Component({
    selector: 'egreso-stock-form',
    standalone: true,
    imports: [
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        ButtonComponent,
        LoadingOverlayComponent
    ],
    templateUrl: './egreso-stock-form.component.html',
    styleUrl: './egreso-stock-form.component.scss'
})

export class EgresoStockFormComponent implements OnInit {

    form!: FormGroup;
    codigo!: number;

    producto: any;

    constructor(
        private fb: FormBuilder,
        private route: ActivatedRoute,
        private detalleStockService: DetalleStockService,
        private service: BaseService<any>,
        public router: Router

    ) { }


    ngOnInit(): void {

        this.route.queryParams.subscribe(params => {
            this.codigo = params['codigo']

            this.service.getByCodigo(this.codigo, 'producto/codigo/').subscribe(producto => {
                this.producto = producto;

                this.form = this.fb.group({
                    cantidad: [null, [Validators.required, Validators.min(1)]],
                    responsable: [{ value: 'Usuario autenticado', disabled: true }],
                    solicitante: ['', Validators.required],
                    observacion: ['', Validators.required]
                });
            }
            );

        });
    }


    onCancelar(): void {
        this.form.reset();
        this.router.navigate(['/stock', this.codigo]);
    }

    submit(): void {
        if (this.form.invalid) {
            this.form.markAllAsTouched();
            return;
        }

        const payload = {
            codigo: this.codigo,
            ...this.form.getRawValue()
        };

        console.log(payload);
        this.detalleStockService.nuevoEgreso(payload).subscribe((data) => {

            alert('Enviado correctamente');//aca podemos utilizar las notificaciones que ya tenemos
            this.router.navigate(['/stock', this.codigo]);
        });

    }
    irADetalleStock() {
        this.router.navigate(['/stock', this.codigo]);
    }
}
